from tkinter import *
from PIL import ImageTk, Image
import numpy as np
import matplotlib.pyplot as plt
root = Tk()
root.title("Image in tkinter")
global s
global t
global my_ui
s=0
def forward(img_number):
    global labe12
    global s
    global label
    global forward_button
    global backward_button
    global mylist
    global city_choice
    s=0
    label.grid_forget()
    if(img_number==6):
     img_number=1
    label=Label(image=mylist[img_number-1])
    forward_button=Button(root,text=">",command=lambda:forward(img_number+1))
    backward_button=Button(root,text="<",command=lambda:backward(img_number-1))
    label.grid(row=0,column=0,columnspan=3)
    forward_button.grid(row=1,column=3)
    backward_button.grid(row=1,column=0)
    exit_button.grid(row=1,column=1)
    if(img_number==2):
     city_choice.grid_forget()
     city_choice=Button(root,text="delhi",command=lambda:delhi_areas(1))
    if(img_number==3):
     city_choice.grid_forget()
     city_choice=Button(root,text="banglore",command=lambda:banglore_areas(1))
    if(img_number==4):
     city_choice.grid_forget()
     city_choice=Button(root,text="kolkata",command=lambda:kolkata_areas(1))
    if(img_number==5):
     city_choice.grid_forget()
     city_choice=Button(root,text="ahemedabad",command=lambda:ahmedabad_areas(1))
    if(img_number==1):
     city_choice.grid_forget()
     city_choice=Button(root,text="mumbai",command=lambda:mumbai_areas(1))
    city_choice.grid(row=1,column=2)
    return 0
def backward(img_number):
    global labe12
    global s
    global label
    global forward_button
    global backward_button
    global mylist
    global city_choice
    if(s==1):
     label.grid_forget()
     city_choice.grid_forget()
     forward_button.grid_forget()
     backward_button.grid_forget()
     return 0
    s=0
    label.grid_forget()
    if(img_number==0):
     img_number=5
    label=Label(image=mylist[img_number-1])
    forward_button=Button(root,text=">",command=lambda:forward(img_number+1))
    backward_button=Button(root,text="<",command=lambda:backward(img_number-1))
    label.grid(row=0,column=0,columnspan=3)
    forward_button.grid(row=1,column=3)
    backward_button.grid(row=1,column=0)
    exit_button.grid(row=1,column=1)
    if(img_number==2):  
     city_choice.grid_forget()
     city_choice=Button(root,text="delhi",command=lambda:delhi_areas(1))
    if(img_number==3):
     city_choice.grid_forget()
     city_choice=Button(root,text="banglore",command=lambda:banglore_areas(1))
    if(img_number==4):
     city_choice.grid_forget()
     city_choice=Button(root,text="kolkata",command=lambda:kolkata_areas(1))
    if(img_number==5):
     city_choice.grid_forget()
     city_choice=Button(root,text="ahemedabad",command=lambda:ahmedabad_areas(1))
    if(img_number==1):
     city_choice.grid_forget()
     city_choice=Button(root,text="mumbai",command=lambda:mumbai_areas(1))
    city_choice.grid(row=1,column=2)
def mumbai_areas(numbers):
 global labe12
 global hu
 hu=e.get()
 e.grid_forget()
 labe12.grid_forget()
 global label1
 global label
 global forward_button
 global backward_button
 global city_choice
 global my_ui
 
 label1.grid_forget()
 label1=Label(root,text="please select your desired area of your choice in mumbai")
 label1.grid(row=2,column=0,columnspan=4)
 mylist.clear()
 label.grid_forget()
 city_choice.grid_forget()
 if(numbers==0):
    numbers=6
 if(numbers==7):
    numbers=1
 if(numbers==1):
 
  label.grid_forget()
  city_choice=Button(root,text="Thane west",command=thane_west)
  
  my_ui=Image.open("thane west.png")
  my_ui=my_ui.resize((700, 600))
  my_ui= ImageTk.PhotoImage(my_ui)
  label =Label(root, image=my_ui)
  label.grid(row=0,column=0,columnspan=4)
  labe12=Label(root,text=str(float(hu)/35200)+" square feet of property you are able to buy in thane west")
  labe12.grid(row=3,column=0,columnspan=4)
 if(numbers==3):
  labe12.grid_forget()
  label.grid_forget()
  city_choice=Button(root,text="Goregaon East",command=goregaon_east)
  my_ui=Image.open("goregaon east.png")
  my_ui=my_ui.resize((700, 600))
  my_ui= ImageTk.PhotoImage(my_ui)
  label =Label(root, image=my_ui)
  label.grid(row=0,column=0,columnspan=4)
  labe12=Label(root,text=str(float(hu)/29400)+" square feet of property you are able to buy in Goregaon east")
  labe12.grid(row=3,column=0,columnspan=4)
 if(numbers==4):
  labe12.grid_forget()
  label.grid_forget()
  city_choice=Button(root,text="Bandra West",command=bandra_west)
  my_ui=Image.open("bandra west.png")
  my_ui=my_ui.resize((700, 600))
  my_ui= ImageTk.PhotoImage(my_ui)
  label =Label(root, image=my_ui)
  label.grid(row=0,column=0,columnspan=4)
  labe12=Label(root,text=str(float(hu)/57900)+" square feet of property you are able to buy in Bandra west")
  labe12.grid(row=3,column=0,columnspan=4)
 if(numbers==5):
  labe12.grid_forget()
  label.grid_forget()
  city_choice=Button(root,text="Juhu",command=juhu)
  my_ui=Image.open("juhu.png")
  my_ui=my_ui.resize((700, 600))
  my_ui= ImageTk.PhotoImage(my_ui)
  label =Label(root, image=my_ui)
  label.grid(row=0,column=0,columnspan=4)
  labe12=Label(root,text=str(float(hu)/59300)+" square feet of property you are able to buy in Juhu")
  labe12.grid(row=3,column=0,columnspan=4)
 if(numbers==6):
  labe12.grid_forget()
  label.grid_forget()
  city_choice=Button(root,text="Andheri West",command=andheri_west)
  my_ui=Image.open("andheri west.png")
  my_ui=my_ui.resize((700, 600))
  my_ui= ImageTk.PhotoImage(my_ui)
  label =Label(root, image=my_ui)
  label.grid(row=0,column=0,columnspan=4)
  
  labe12=Label(root,text=str(float(hu)/35350)+" square feet of property you are able to buy in andheri west")
  labe12.grid(row=3,column=0,columnspan=4)
 if(numbers==2):
 
  label.grid_forget()
  city_choice=Button(root,text="Powai",command=powai)
  my_ui=Image.open("powai.png")
  my_ui=my_ui.resize((700, 600))
  my_ui= ImageTk.PhotoImage(my_ui)
  label =Label(root, image=my_ui)
  label.grid(row=0,column=0,columnspan=4)
  labe12=Label(root,text=str(float(hu)/35200)+" square feet of property you are able to buy in Powai")
  labe12.grid(row=3,column=0,columnspan=4)
 forward_button=Button(root,text=">",command=lambda:mumbai_areas(numbers+1))
 backward_button=Button(root,text="<",command=lambda:mumbai_areas(numbers-1))
 forward_button.grid(row=1,column=3)
 backward_button.grid(row=1,column=0)
 exit_button.grid(row=1,column=1)
 city_choice.grid(row=1,column=2)
def andheri_west():
 global label
 global forward_button
 global backward_button
 global city_choice
 global data_points
 global x_values
 city_choice.grid_forget()
 label.grid_forget()
 label1.grid_forget()
 root.destroy()
 top=Tk()
 data_points = np.array([20400, 20000, 23200, 24200, 25300, 24650, 25100, 27200, 27500, 26500,
                   26300, 28750, 29200, 28400, 27800, 27950, 28750, 29450, 29500, 27950,
                   28650, 28850, 28650, 29300, 28550, 28700, 29050, 28700, 28700, 29200,
                   28900, 30900, 30500, 30500, 30900, 31350, 31150, 31000, 34650, 33600,
                   35200])
 x_values = np.arange(len(data_points))
 coefficients = np.polyfit(x_values, data_points, 4)
 poly_equation = np.poly1d(coefficients)
 x_regression = np.linspace(0, len(data_points)+5, 100)
 y_regression = poly_equation(x_regression)
 plt.scatter(x_values, data_points, label='Data Points')
 plt.plot(x_regression, y_regression, label=f'4-Degree Polynomial Regression\n{poly_equation}', color='red')
 next_x_values = np.arange(len(data_points), len(data_points)+6)
 next_y_values = poly_equation(next_x_values)
 global label22
 label=Label(top,text="predicted values of property prices")
 label22=Label(top,text=next_y_values)
 label.grid(row=0,column=0,columnspan=2)
 label22.grid(row=0,column=2,columnspan=2)
 plt.scatter(next_x_values, next_y_values, label='Predicted Points', color='green', marker='x')
 plt.legend()
 plt.show()
def powai():
 global label
 global forward_button
 global backward_button
 global city_choice
 city_choice.grid_forget()
 label.destroy()
 label1.destroy()
 root.destroy()
 top=Tk()
 data_points = np.array([20400, 20000, 23200, 24200, 25300, 24650, 25100, 27200, 27500, 26500,
                   26300, 28750, 29200, 28400, 27800, 27950, 28750, 29450, 29500, 27950,
                   28650, 28850, 28650, 29300, 28550, 28700, 29050, 28700, 28700, 29200,
                   28900, 30900, 30500, 30500, 30900, 31350, 31150, 31000, 34650, 33600,
                   35200])
 x_values = np.arange(len(data_points))
 coefficients = np.polyfit(x_values, data_points, 4)
 poly_equation = np.poly1d(coefficients)
 x_regression = np.linspace(0, len(data_points)+5, 100)
 y_regression = poly_equation(x_regression)
 plt.scatter(x_values, data_points, label='Data Points')
 plt.plot(x_regression, y_regression, label=f'4-Degree Polynomial Regression\n{poly_equation}', color='red')
 next_x_values = np.arange(len(data_points), len(data_points)+6)
 next_y_values = poly_equation(next_x_values)
 global label22
 label=Label(top,text="predicted values of property prices")
 label22=Label(top,text=next_y_values)
 label.grid(row=0,column=0,columnspan=2)
 label22.grid(row=0,column=2,columnspan=2)
 plt.scatter(next_x_values, next_y_values, label='Predicted Points', color='green', marker='x')
 plt.legend()
 plt.show()
 
def juhu():
 global label
 global forward_button
 global backward_button
 global city_choice
 city_choice.grid_forget()
 label.destroy()
 label1.destroy()
 root.destroy()
 top=Tk()
 data_points = np.array([20400, 20000, 23200, 24200, 25300, 24650, 25100, 27200, 27500, 26500,
                   26300, 28750, 29200, 28400, 27800, 27950, 28750, 29450, 29500, 27950,
                   28650, 28850, 28650, 29300, 28550, 28700, 29050, 28700, 28700, 29200,
                   28900, 30900, 30500, 30500, 30900, 31350, 31150, 31000, 34650, 33600,
                   35200])
 x_values = np.arange(len(data_points))
 coefficients = np.polyfit(x_values, data_points, 4)
 poly_equation = np.poly1d(coefficients)
 x_regression = np.linspace(0, len(data_points)+5, 100)
 y_regression = poly_equation(x_regression)
 plt.scatter(x_values, data_points, label='Data Points')
 plt.plot(x_regression, y_regression, label=f'4-Degree Polynomial Regression\n{poly_equation}', color='red')
 next_x_values = np.arange(len(data_points), len(data_points)+6)
 next_y_values = poly_equation(next_x_values)
 global label22
 label=Label(top,text="predicted values of property prices")
 label22=Label(top,text=next_y_values)
 label.grid(row=0,column=0,columnspan=2)
 label22.grid(row=0,column=2,columnspan=2)
 plt.scatter(next_x_values, next_y_values, label='Predicted Points', color='green', marker='x')
 plt.legend()
 plt.show()
def bandra_west():
 global label
 global forward_button
 global backward_button
 global city_choice
 city_choice.grid_forget()
 label.destroy()
 label1.destroy()
 root.destroy()
 top=Tk()
 data_points = np.array([20400, 20000, 23200, 24200, 25300, 24650, 25100, 27200, 27500, 26500,
                   26300, 28750, 29200, 28400, 27800, 27950, 28750, 29450, 29500, 27950,
                   28650, 28850, 28650, 29300, 28550, 28700, 29050, 28700, 28700, 29200,
                   28900, 30900, 30500, 30500, 30900, 31350, 31150, 31000, 34650, 33600,
                   35200])
 x_values = np.arange(len(data_points))
 coefficients = np.polyfit(x_values, data_points, 4)
 poly_equation = np.poly1d(coefficients)
 x_regression = np.linspace(0, len(data_points)+5, 100)
 y_regression = poly_equation(x_regression)
 plt.scatter(x_values, data_points, label='Data Points')
 plt.plot(x_regression, y_regression, label=f'4-Degree Polynomial Regression\n{poly_equation}', color='red')
 next_x_values = np.arange(len(data_points), len(data_points)+6)
 next_y_values = poly_equation(next_x_values)
 global label22
 label=Label(top,text="predicted values of property prices")
 label22=Label(top,text=next_y_values)
 label.grid(row=0,column=0,columnspan=2)
 label22.grid(row=0,column=2,columnspan=2)
 plt.scatter(next_x_values, next_y_values, label='Predicted Points', color='green', marker='x')
 plt.legend()
 plt.show()
def goregaon_east():
 global label
 global forward_button
 global backward_button
 global city_choice
 city_choice.grid_forget()
 label.destroy()
 label1.destroy()
 root.destroy()
 top=Tk()
 data_points = np.array([20400, 20000, 23200, 24200, 25300, 24650, 25100, 27200, 27500, 26500,
                   26300, 28750, 29200, 28400, 27800, 27950, 28750, 29450, 29500, 27950,
                   28650, 28850, 28650, 29300, 28550, 28700, 29050, 28700, 28700, 29200,
                   28900, 30900, 30500, 30500, 30900, 31350, 31150, 31000, 34650, 33600,
                   35200])
 x_values = np.arange(len(data_points))
 coefficients = np.polyfit(x_values, data_points, 4)
 poly_equation = np.poly1d(coefficients)
 x_regression = np.linspace(0, len(data_points)+5, 100)
 y_regression = poly_equation(x_regression)
 plt.scatter(x_values, data_points, label='Data Points')
 plt.plot(x_regression, y_regression, label=f'4-Degree Polynomial Regression\n{poly_equation}', color='red')
 next_x_values = np.arange(len(data_points), len(data_points)+6)
 next_y_values = poly_equation(next_x_values)
 global label22
 label=Label(top,text="predicted values of property prices")
 label22=Label(top,text=next_y_values)
 label.grid(row=0,column=0,columnspan=2)
 label22.grid(row=0,column=2,columnspan=2)
 plt.scatter(next_x_values, next_y_values, label='Predicted Points', color='green', marker='x')
 plt.legend()
 plt.show()
def thane_west():
 global label
 global forward_button
 global backward_button
 global city_choice
 city_choice.grid_forget()
 label.destroy()
 label1.destroy()
 root.destroy()
 top=Tk()
 data_points = np.array([20400, 20000, 23200, 24200, 25300, 24650, 25100, 27200, 27500, 26500,
                   26300, 28750, 29200, 28400, 27800, 27950, 28750, 29450, 29500, 27950,
                   28650, 28850, 28650, 29300, 28550, 28700, 29050, 28700, 28700, 29200,
                   28900, 30900, 30500, 30500, 30900, 31350, 31150, 31000, 34650, 33600,
                   35200])
 x_values = np.arange(len(data_points))
 coefficients = np.polyfit(x_values, data_points, 4)
 poly_equation = np.poly1d(coefficients)
 x_regression = np.linspace(0, len(data_points)+5, 100)
 y_regression = poly_equation(x_regression)
 plt.scatter(x_values, data_points, label='Data Points')
 plt.plot(x_regression, y_regression, label=f'4-Degree Polynomial Regression\n{poly_equation}', color='red')
 next_x_values = np.arange(len(data_points), len(data_points)+6)
 next_y_values = poly_equation(next_x_values)
 global label22
 label=Label(top,text="predicted values of property prices")
 label22=Label(top,text=next_y_values)
 label.grid(row=0,column=0,columnspan=2)
 label22.grid(row=0,column=2,columnspan=2)
 plt.scatter(next_x_values, next_y_values, label='Predicted Points', color='green', marker='x')
 plt.legend()
 plt.show()
def delhi_areas(numbers):
 global labe12
 global hu
 hu=e.get()
 e.grid_forget()
 labe12.grid_forget()
 global label1
 label1.grid_forget()
 label1=Label(root,text="please select your desired area of your choice in delhi")
 label1.grid(row=2,column=0,columnspan=4)
 global label
 global forward_button
 global backward_button
 global city_choice
 mylist.clear()
 label.grid_forget()
 

 city_choice.grid_forget()
 if(numbers==0):
    numbers=6
 if(numbers==7):
    numbers=1
 if(numbers==1):
  label.grid_forget()
  city_choice=Button(root,text="dwarka sector 6",command=dwarka_sector_6)
  my_ui1=Image.open("dwarka_sector_6.jpg")
  my_ui1=my_ui1.resize((700, 600))
  my_ui1= ImageTk.PhotoImage(my_ui1)
  label =Label(root, image=my_ui1)
  label.grid(row=0,column=0,columnspan=4)
  labe12=Label(root,text=str(int(hu)/11400)+" square feet of property you are able to buy in Dwarka sector 6")
  labe12.grid(row=3,column=0,columnspan=4)
 if(numbers==2):
  labe12.grid_forget()
  label.grid_forget()
  city_choice=Button(root,text="Paschim Vihar",command=paschim_vihar)
  my_ui1=Image.open("paschim vihar.png")
  my_ui1=my_ui1.resize((700, 600))
  my_ui1= ImageTk.PhotoImage(my_ui1)
  label =Label(root, image=my_ui1)
  label.grid(row=0,column=0,columnspan=4)
  labe12=Label(root,text=str(float(hu)/11000)+" square feet of property you are able to buy in paschim vihar")
  labe12.grid(row=3,column=0,columnspan=4)
 if(numbers==3):
   labe12.grid_forget()
   label.grid_forget()
   city_choice=Button(root,text="Sector 13 Rohini",command=sector_13_rohini)
   my_ui1=Image.open("sector 13 rohini.png")
   my_ui1=my_ui1.resize((700, 600))
   my_ui1= ImageTk.PhotoImage(my_ui1)
   label =Label(root, image=my_ui1)
   label.grid(row=0,column=0,columnspan=4)
   labe12=Label(root,text=str(float(hu)/14450)+" square feet of property you are able to buy in sector 13 Rohini")
   labe12.grid(row=3,column=0,columnspan=4)
 if(numbers==4):
   labe12.grid_forget()
   label.grid_forget()
   city_choice=Button(root,text="Shalimar Bagh",command=shalimar_bagh)
   my_ui1=Image.open("shalimar bagh.png")
   my_ui1=my_ui1.resize((700, 600))
   my_ui1= ImageTk.PhotoImage(my_ui1)
   label =Label(root, image=my_ui1)
   label.grid(row=0,column=0,columnspan=4)
   labe12=Label(root,text=str(float(hu)/11700)+" square feet of property you are able to buy in Shalimar bagh")
   labe12.grid(row=3,column=0,columnspan=4)
 if(numbers==5):
  labe12.grid_forget()
  label.grid_forget()
  city_choice=Button(root,text="Okhla",command=okhla)
  my_ui1=Image.open("okhla.png")
  my_ui1=my_ui1.resize((700, 600))
  my_ui1= ImageTk.PhotoImage(my_ui1)
  label =Label(root, image=my_ui1)
  label.grid(row=0,column=0,columnspan=4)
  labe12=Label(root,text=str(float(hu)/24500)+" square feet of property you are able to buy in Okhla")
  labe12.grid(row=3,column=0,columnspan=4)
 if(numbers==6):
  labe12.grid_forget()
  label.grid_forget()
  city_choice=Button(root,text="Janakpuri",command=janakpuri)
  my_ui1=Image.open("powai.png")
  my_ui1=my_ui1.resize((700, 600))
  my_ui1= ImageTk.PhotoImage(my_ui1)
  label =Label(root, image=my_ui1)
  label.grid(row=0,column=0,columnspan=4)
  labe12=Label(root,text=str(float(hu)/13150)+" square feet of property you are able to buy in Janakpuri")
  labe12.grid(row=3,column=0,columnspan=4)
  
 forward_button=Button(root,text=">",command=lambda:delhi_areas(numbers+1))
 backward_button=Button(root,text="<",command=lambda:delhi_areas(numbers-1))
 forward_button.grid(row=1,column=3)
 backward_button.grid(row=1,column=0)
 exit_button.grid(row=1,column=1)
 city_choice.grid(row=1,column=2)
def dwarka_sector_6():
 global label
 global forward_button
 global backward_button
 global city_choice
 forward_button.grid_forget() 
 backward_button.grid_forget()
 city_choice.grid_forget()
 label.destroy()
 label1.destroy()
 root.destroy()
 top=Tk()
 data_points = np.array([20400, 20000, 23200, 24200, 25300, 24650, 25100, 27200, 27500, 26500,
                   26300, 28750, 29200, 28400, 27800, 27950, 28750, 29450, 29500, 27950,
                   28650, 28850, 28650, 29300, 28550, 28700, 29050, 28700, 28700, 29200,
                   28900, 30900, 30500, 30500, 30900, 31350, 31150, 31000, 34650, 33600,
                   35200])
 x_values = np.arange(len(data_points))
 coefficients = np.polyfit(x_values, data_points, 4)
 poly_equation = np.poly1d(coefficients)
 x_regression = np.linspace(0, len(data_points)+5, 100)
 y_regression = poly_equation(x_regression)
 plt.scatter(x_values, data_points, label='Data Points')
 plt.plot(x_regression, y_regression, label=f'4-Degree Polynomial Regression\n{poly_equation}', color='red')
 next_x_values = np.arange(len(data_points), len(data_points)+6)
 next_y_values = poly_equation(next_x_values)
 global label22
 label=Label(top,text="predicted values of property prices")
 label22=Label(top,text=next_y_values)
 label.grid(row=0,column=0,columnspan=2)
 label22.grid(row=0,column=2,columnspan=2)
 plt.scatter(next_x_values, next_y_values, label='Predicted Points', color='green', marker='x')
 plt.legend()
 plt.show()
def paschim_vihar():
 global label
 global forward_button
 global backward_button
 global city_choice
 city_choice.grid_forget()
 label.destroy()
 label1.destroy()
 root.destroy()
 top=Tk()
 data_points = np.array([20400, 20000, 23200, 24200, 25300, 24650, 25100, 27200, 27500, 26500,
                   26300, 28750, 29200, 28400, 27800, 27950, 28750, 29450, 29500, 27950,
                   28650, 28850, 28650, 29300, 28550, 28700, 29050, 28700, 28700, 29200,
                   28900, 30900, 30500, 30500, 30900, 31350, 31150, 31000, 34650, 33600,
                   35200])
 x_values = np.arange(len(data_points))
 coefficients = np.polyfit(x_values, data_points, 4)
 poly_equation = np.poly1d(coefficients)
 x_regression = np.linspace(0, len(data_points)+5, 100)
 y_regression = poly_equation(x_regression)
 plt.scatter(x_values, data_points, label='Data Points')
 plt.plot(x_regression, y_regression, label=f'4-Degree Polynomial Regression\n{poly_equation}', color='red')
 next_x_values = np.arange(len(data_points), len(data_points)+6)
 next_y_values = poly_equation(next_x_values)
 global label22
 label=Label(top,text="predicted values of property prices")
 label22=Label(top,text=next_y_values)
 label.grid(row=0,column=0,columnspan=2)
 label22.grid(row=0,column=2,columnspan=2)
 plt.scatter(next_x_values, next_y_values, label='Predicted Points', color='green', marker='x')
 plt.legend()
 plt.show()
def sector_13_rohini():
 global label
 global forward_button
 global backward_button
 global city_choice
 city_choice.grid_forget()
 label.destroy()
 label1.destroy()
 root.destroy()
 top=Tk()
 data_points = np.array([20400, 20000, 23200, 24200, 25300, 24650, 25100, 27200, 27500, 26500,
                   26300, 28750, 29200, 28400, 27800, 27950, 28750, 29450, 29500, 27950,
                   28650, 28850, 28650, 29300, 28550, 28700, 29050, 28700, 28700, 29200,
                   28900, 30900, 30500, 30500, 30900, 31350, 31150, 31000, 34650, 33600,
                   35200])
 x_values = np.arange(len(data_points))
 coefficients = np.polyfit(x_values, data_points, 4)
 poly_equation = np.poly1d(coefficients)
 x_regression = np.linspace(0, len(data_points)+5, 100)
 y_regression = poly_equation(x_regression)
 plt.scatter(x_values, data_points, label='Data Points')
 plt.plot(x_regression, y_regression, label=f'4-Degree Polynomial Regression\n{poly_equation}', color='red')
 next_x_values = np.arange(len(data_points), len(data_points)+6)
 next_y_values = poly_equation(next_x_values)
 global label22
 label=Label(top,text="predicted values of property prices")
 label22=Label(top,text=next_y_values)
 label.grid(row=0,column=0,columnspan=2)
 label22.grid(row=0,column=2,columnspan=2)
 plt.scatter(next_x_values, next_y_values, label='Predicted Points', color='green', marker='x')
 plt.legend()
 plt.show()
def shalimar_bagh():
 global label
 global forward_button
 global backward_button
 global city_choice
 city_choice.grid_forget()
 label.destroy()
 label1.destroy()
 root.destroy()
 top=Tk()
 data_points = np.array([20400, 20000, 23200, 24200, 25300, 24650, 25100, 27200, 27500, 26500,
                   26300, 28750, 29200, 28400, 27800, 27950, 28750, 29450, 29500, 27950,
                   28650, 28850, 28650, 29300, 28550, 28700, 29050, 28700, 28700, 29200,
                   28900, 30900, 30500, 30500, 30900, 31350, 31150, 31000, 34650, 33600,
                   35200])
 x_values = np.arange(len(data_points))
 coefficients = np.polyfit(x_values, data_points, 4)
 poly_equation = np.poly1d(coefficients)
 x_regression = np.linspace(0, len(data_points)+5, 100)
 y_regression = poly_equation(x_regression)
 plt.scatter(x_values, data_points, label='Data Points')
 plt.plot(x_regression, y_regression, label=f'4-Degree Polynomial Regression\n{poly_equation}', color='red')
 next_x_values = np.arange(len(data_points), len(data_points)+6)
 next_y_values = poly_equation(next_x_values)
 global label22
 label=Label(top,text="predicted values of property prices")
 label22=Label(top,text=next_y_values)
 label.grid(row=0,column=0,columnspan=2)
 label22.grid(row=0,column=2,columnspan=2)
 plt.scatter(next_x_values, next_y_values, label='Predicted Points', color='green', marker='x')
 plt.legend()
 plt.show()
def okhla():
 global label
 global forward_button
 global backward_button
 global city_choice
 city_choice.grid_forget()
 label.destroy()
 label1.destroy()
 root.destroy()
 top=Tk()
 data_points = np.array([20400, 20000, 23200, 24200, 25300, 24650, 25100, 27200, 27500, 26500,
                   26300, 28750, 29200, 28400, 27800, 27950, 28750, 29450, 29500, 27950,
                   28650, 28850, 28650, 29300, 28550, 28700, 29050, 28700, 28700, 29200,
                   28900, 30900, 30500, 30500, 30900, 31350, 31150, 31000, 34650, 33600,
                   35200])
 x_values = np.arange(len(data_points))
 coefficients = np.polyfit(x_values, data_points, 4)
 poly_equation = np.poly1d(coefficients)
 x_regression = np.linspace(0, len(data_points)+5, 100)
 y_regression = poly_equation(x_regression)
 plt.scatter(x_values, data_points, label='Data Points')
 plt.plot(x_regression, y_regression, label=f'4-Degree Polynomial Regression\n{poly_equation}', color='red')
 next_x_values = np.arange(len(data_points), len(data_points)+6)
 next_y_values = poly_equation(next_x_values)
 global label22
 label=Label(top,text="predicted values of property prices")
 label22=Label(top,text=next_y_values)
 label.grid(row=0,column=0,columnspan=2)
 label22.grid(row=0,column=2,columnspan=2)
 plt.scatter(next_x_values, next_y_values, label='Predicted Points', color='green', marker='x')
 plt.legend()
 plt.show()
def janakpuri():
 global label
 global forward_button
 global backward_button
 global city_choice
 city_choice.grid_forget()
 label.destroy()
 label1.destroy()
 root.destroy()
 top=Tk()
 data_points = np.array([20400, 20000, 23200, 24200, 25300, 24650, 25100, 27200, 27500, 26500,
                   26300, 28750, 29200, 28400, 27800, 27950, 28750, 29450, 29500, 27950,
                   28650, 28850, 28650, 29300, 28550, 28700, 29050, 28700, 28700, 29200,
                   28900, 30900, 30500, 30500, 30900, 31350, 31150, 31000, 34650, 33600,
                   35200])
 x_values = np.arange(len(data_points))
 coefficients = np.polyfit(x_values, data_points, 4)
 poly_equation = np.poly1d(coefficients)
 x_regression = np.linspace(0, len(data_points)+5, 100)
 y_regression = poly_equation(x_regression)
 plt.scatter(x_values, data_points, label='Data Points')
 plt.plot(x_regression, y_regression, label=f'4-Degree Polynomial Regression\n{poly_equation}', color='red')
 next_x_values = np.arange(len(data_points), len(data_points)+6)
 next_y_values = poly_equation(next_x_values)
 global label22
 label=Label(top,text="predicted values of property prices")
 label22=Label(top,text=next_y_values)
 label.grid(row=0,column=0,columnspan=2)
 label22.grid(row=0,column=2,columnspan=2)
 plt.scatter(next_x_values, next_y_values, label='Predicted Points', color='green', marker='x')
 plt.legend()
 plt.show()
def kolkata_areas(numbers):
 global labe12
 global hu
 hu=e.get()
 e.grid_forget()
 labe12.grid_forget()
 global label1
 label1.grid_forget()
 label1=Label(root,text="please select your desired area of your choice in kolkata")
 label1.grid(row=2,column=0,columnspan=2)
 global label
 global forward_button
 global backward_button
 global city_choice
 mylist.clear()
 label.grid_forget()
 city_choice.grid_forget()
 if(numbers==0):
    numbers=6
 if(numbers==7):
    numbers=1
 if(numbers==2):
  labe12.grid_forget()
  label.grid_forget()
  city_choice=Button(root,text="Dum Dum")
  my_ui=Image.open("powai.png")
  my_ui=my_ui.resize((700, 600))
  my_ui= ImageTk.PhotoImage(my_ui)
  label =Label(root, image=my_ui)
  label.grid(row=0,column=0,columnspan=4)
  labe12=Label(root,text=str(float(hu)/3900)+" square feet of property you are able to buy in dum dum")
  labe12.grid(row=3,column=0,columnspan=4)
 if(numbers==3):
  labe12.grid_forget()
  label.grid_forget()
  city_choice=Button(root,text="Madhyamgram",command=Madhyamgram)
  my_ui=Image.open("powai.png")
  my_ui=my_ui.resize((700, 600))
  my_ui= ImageTk.PhotoImage(my_ui)
  label =Label(root, image=my_ui)
  label.grid(row=0,column=0,columnspan=4)
  labe12=Label(root,text=str(float(hu)/3450)+" square feet of property you are able to buy in madhyamgram")
  labe12.grid(row=3,column=0,columnspan=4)
 if(numbers==4):
  labe12.grid_forget()
  label.grid_forget()
  city_choice=Button(root,text="Howrah",command=howrah)
  my_ui=Image.open("powai.png")
  my_ui=my_ui.resize((700, 600))
  my_ui= ImageTk.PhotoImage(my_ui)
  label =Label(root, image=my_ui)
  label.grid(row=0,column=0,columnspan=4)
  labe12=Label(root,text=str(float(hu)/4400)+" square feet of property you are able to buy in Howrah")
  labe12.grid(row=3,column=0,columnspan=4)
 if(numbers==5):
  labe12.grid_forget()
  label.grid_forget()
  city_choice=Button(root,text="Jadavpur",command=jadavpur)
  my_ui=Image.open("powai.png")
  my_ui=my_ui.resize((700, 600))
  my_ui= ImageTk.PhotoImage(my_ui)
  label =Label(root, image=my_ui)
  label.grid(row=0,column=0,columnspan=4)
  labe12=Label(root,text=str(float(hu)/5000)+" square feet of property you are able to buy in jadavpur")
  labe12.grid(row=3,column=0,columnspan=4)
 if(numbers==6):
  labe12.grid_forget()
  label.grid_forget()
  city_choice=Button(root,text="Nayabad",command=nayabad)
  my_ui=Image.open("powai.png")
  my_ui=my_ui.resize((700, 600))
  my_ui= ImageTk.PhotoImage(my_ui)
  label =Label(root, image=my_ui)
  label.grid(row=0,column=0,columnspan=4)
  labe12=Label(root,text=str(float(hu)/4050)+" square feet of property you are able to buy in Nayabad")
  labe12.grid(row=3,column=0,columnspan=4)
 if(numbers==1):
  
  label.grid_forget()
  city_choice=Button(root,text="Picnic Garden",command=picnic_garden)
  my_ui=Image.open("powai.png")
  my_ui=my_ui.resize((700, 600))
  my_ui= ImageTk.PhotoImage(my_ui)
  label =Label(root, image=my_ui)
  label.grid(row=0,column=0,columnspan=4)
  labe12=Label(root,text=str(float(hu)/5800)+" square feet of property you are able to buy in Picnic garden")
  labe12.grid(row=3,column=0,columnspan=4)
 forward_button=Button(root,text=">",command=lambda:kolkata_areas(numbers+1))
 backward_button=Button(root,text="<",command=lambda:kolkata_areas(numbers-1))
 forward_button.grid(row=1,column=3)
 backward_button.grid(row=1,column=0)
 exit_button.grid(row=1,column=1)
 city_choice.grid(row=1,column=2)
def Madhyamgram():
 global label
 global forward_button
 global backward_button
 global city_choice
 city_choice.grid_forget()
 label.destroy()
 label1.destroy()
 root.destroy()
 top=Tk()
 data_points = np.array([20400, 20000, 23200, 24200, 25300, 24650, 25100, 27200, 27500, 26500,
                   26300, 28750, 29200, 28400, 27800, 27950, 28750, 29450, 29500, 27950,
                   28650, 28850, 28650, 29300, 28550, 28700, 29050, 28700, 28700, 29200,
                   28900, 30900, 30500, 30500, 30900, 31350, 31150, 31000, 34650, 33600,
                   35200])
 x_values = np.arange(len(data_points))
 coefficients = np.polyfit(x_values, data_points, 4)
 poly_equation = np.poly1d(coefficients)
 x_regression = np.linspace(0, len(data_points)+5, 100)
 y_regression = poly_equation(x_regression)
 plt.scatter(x_values, data_points, label='Data Points')
 plt.plot(x_regression, y_regression, label=f'4-Degree Polynomial Regression\n{poly_equation}', color='red')
 next_x_values = np.arange(len(data_points), len(data_points)+6)
 next_y_values = poly_equation(next_x_values)
 global label22
 label=Label(top,text="predicted values of property prices")
 label22=Label(top,text=next_y_values)
 label.grid(row=0,column=0,columnspan=2)
 label22.grid(row=0,column=2,columnspan=2)
 plt.scatter(next_x_values, next_y_values, label='Predicted Points', color='green', marker='x')
 plt.legend()
 plt.show()
def howrah():
 global label
 global forward_button
 global backward_button
 global city_choice
 city_choice.grid_forget()
 label.destroy()
 label1.destroy()
 root.destroy()
 top=Tk()
 data_points = np.array([20400, 20000, 23200, 24200, 25300, 24650, 25100, 27200, 27500, 26500,
                   26300, 28750, 29200, 28400, 27800, 27950, 28750, 29450, 29500, 27950,
                   28650, 28850, 28650, 29300, 28550, 28700, 29050, 28700, 28700, 29200,
                   28900, 30900, 30500, 30500, 30900, 31350, 31150, 31000, 34650, 33600,
                   35200])
 x_values = np.arange(len(data_points))
 coefficients = np.polyfit(x_values, data_points, 4)
 poly_equation = np.poly1d(coefficients)
 x_regression = np.linspace(0, len(data_points)+5, 100)
 y_regression = poly_equation(x_regression)
 plt.scatter(x_values, data_points, label='Data Points')
 plt.plot(x_regression, y_regression, label=f'4-Degree Polynomial Regression\n{poly_equation}', color='red')
 next_x_values = np.arange(len(data_points), len(data_points)+6)
 next_y_values = poly_equation(next_x_values)
 global label22
 label=Label(top,text="predicted values of property prices")
 label22=Label(top,text=next_y_values)
 label.grid(row=0,column=0,columnspan=2)
 label22.grid(row=0,column=2,columnspan=2)
 plt.scatter(next_x_values, next_y_values, label='Predicted Points', color='green', marker='x')
 plt.legend()
 plt.show()
def picnic_garden():
 global label
 global forward_button
 global backward_button
 global city_choice
 city_choice.grid_forget()
 label.destroy()
 label1.destroy()
 root.destroy()
 top=Tk()
 data_points = np.array([20400, 20000, 23200, 24200, 25300, 24650, 25100, 27200, 27500, 26500,
                   26300, 28750, 29200, 28400, 27800, 27950, 28750, 29450, 29500, 27950,
                   28650, 28850, 28650, 29300, 28550, 28700, 29050, 28700, 28700, 29200,
                   28900, 30900, 30500, 30500, 30900, 31350, 31150, 31000, 34650, 33600,
                   35200])
 x_values = np.arange(len(data_points))
 coefficients = np.polyfit(x_values, data_points, 4)
 poly_equation = np.poly1d(coefficients)
 x_regression = np.linspace(0, len(data_points)+5, 100)
 y_regression = poly_equation(x_regression)
 plt.scatter(x_values, data_points, label='Data Points')
 plt.plot(x_regression, y_regression, label=f'4-Degree Polynomial Regression\n{poly_equation}', color='red')
 next_x_values = np.arange(len(data_points), len(data_points)+6)
 next_y_values = poly_equation(next_x_values)
 global label22
 label=Label(top,text="predicted values of property prices")
 label22=Label(top,text=next_y_values)
 label.grid(row=0,column=0,columnspan=2)
 label22.grid(row=0,column=2,columnspan=2)
 plt.scatter(next_x_values, next_y_values, label='Predicted Points', color='green', marker='x')
 plt.legend()
 plt.show()
def nayabad():
 global label
 global forward_button
 global backward_button
 global city_choice
 city_choice.grid_forget()
 label.destroy()
 label1.destroy()
 root.destroy()
 top=Tk()
 data_points = np.array([20400, 20000, 23200, 24200, 25300, 24650, 25100, 27200, 27500, 26500,
                   26300, 28750, 29200, 28400, 27800, 27950, 28750, 29450, 29500, 27950,
                   28650, 28850, 28650, 29300, 28550, 28700, 29050, 28700, 28700, 29200,
                   28900, 30900, 30500, 30500, 30900, 31350, 31150, 31000, 34650, 33600,
                   35200])
 x_values = np.arange(len(data_points))
 coefficients = np.polyfit(x_values, data_points, 4)
 poly_equation = np.poly1d(coefficients)
 x_regression = np.linspace(0, len(data_points)+5, 100)
 y_regression = poly_equation(x_regression)
 plt.scatter(x_values, data_points, label='Data Points')
 plt.plot(x_regression, y_regression, label=f'4-Degree Polynomial Regression\n{poly_equation}', color='red')
 next_x_values = np.arange(len(data_points), len(data_points)+6)
 next_y_values = poly_equation(next_x_values)
 global label22
 label=Label(top,text="predicted values of property prices")
 label22=Label(top,text=next_y_values)
 label.grid(row=0,column=0,columnspan=2)
 label22.grid(row=0,column=2,columnspan=2)
 plt.scatter(next_x_values, next_y_values, label='Predicted Points', color='green', marker='x')
 plt.legend()
 plt.show()
def jadavpur():
 global label
 global forward_button
 global backward_button
 global city_choice
 city_choice.grid_forget()
 label.destroy()
 label1.destroy()
 root.destroy()
 top=Tk()
 data_points = np.array([20400, 20000, 23200, 24200, 25300, 24650, 25100, 27200, 27500, 26500,
                   26300, 28750, 29200, 28400, 27800, 27950, 28750, 29450, 29500, 27950,
                   28650, 28850, 28650, 29300, 28550, 28700, 29050, 28700, 28700, 29200,
                   28900, 30900, 30500, 30500, 30900, 31350, 31150, 31000, 34650, 33600,
                   35200])
 x_values = np.arange(len(data_points))
 coefficients = np.polyfit(x_values, data_points, 4)
 poly_equation = np.poly1d(coefficients)
 x_regression = np.linspace(0, len(data_points)+5, 100)
 y_regression = poly_equation(x_regression)
 plt.scatter(x_values, data_points, label='Data Points')
 plt.plot(x_regression, y_regression, label=f'4-Degree Polynomial Regression\n{poly_equation}', color='red')
 next_x_values = np.arange(len(data_points), len(data_points)+6)
 next_y_values = poly_equation(next_x_values)
 global label22
 label=Label(top,text="predicted values of property prices")
 label22=Label(top,text=next_y_values)
 label.grid(row=0,column=0,columnspan=2)
 label22.grid(row=0,column=2,columnspan=2)
 plt.scatter(next_x_values, next_y_values, label='Predicted Points', color='green', marker='x')
 plt.legend()
 plt.show()
def dum_dum():
 global label
 global forward_button
 global backward_button
 global city_choice
 city_choice.grid_forget()
 label.destroy()
 label1.destroy()
 root.destroy()
 top=Tk()
 data_points = np.array([20400, 20000, 23200, 24200, 25300, 24650, 25100, 27200, 27500, 26500,
                   26300, 28750, 29200, 28400, 27800, 27950, 28750, 29450, 29500, 27950,
                   28650, 28850, 28650, 29300, 28550, 28700, 29050, 28700, 28700, 29200,
                   28900, 30900, 30500, 30500, 30900, 31350, 31150, 31000, 34650, 33600,
                   35200])
 x_values = np.arange(len(data_points))
 coefficients = np.polyfit(x_values, data_points, 4)
 poly_equation = np.poly1d(coefficients)
 x_regression = np.linspace(0, len(data_points)+5, 100)
 y_regression = poly_equation(x_regression)
 plt.scatter(x_values, data_points, label='Data Points')
 plt.plot(x_regression, y_regression, label=f'4-Degree Polynomial Regression\n{poly_equation}', color='red')
 next_x_values = np.arange(len(data_points), len(data_points)+6)
 next_y_values = poly_equation(next_x_values)
 global label22
 label=Label(top,text="predicted values of property prices")
 label22=Label(top,text=next_y_values)
 label.grid(row=0,column=0,columnspan=2)
 label22.grid(row=0,column=2,columnspan=2)
 plt.scatter(next_x_values, next_y_values, label='Predicted Points', color='green', marker='x')
 plt.legend()
 plt.show()
def ahmedabad_areas(numbers):
 global labe12
 global hu
 hu=e.get()
 e.grid_forget()
 labe12.grid_forget()
 global label1
 label1.grid_forget()
 label1=Label(root,text="please select your desired area of your choice in ahmedabad")
 label1.grid(row=2,column=0,columnspan=2)
 global label
 global forward_button
 global backward_button
 global city_choice
 mylist.clear()
 label.grid_forget()
 city_choice.grid_forget()
 if(numbers==0):
    numbers=6
 if(numbers==7):
    numbers=1
 if(numbers==2):
  labe12.grid_forget()
  label.grid_forget()
  city_choice=Button(root,text="Chandkheda",command=chandkheda)
  my_ui=Image.open("powai.png")
  my_ui=my_ui.resize((700, 600))
  my_ui= ImageTk.PhotoImage(my_ui)
  label =Label(root, image=my_ui)
  label.grid(row=0,column=0,columnspan=4)
  labe12=Label(root,text=str(float(hu)/4500)+" square feet of property you are able to buy in Chandkheda")
  labe12.grid(row=3,column=0,columnspan=4)
 if(numbers==3):
  labe12.grid_forget()
  label.grid_forget()
  city_choice=Button(root,text="Bopal",command=bopal)
  my_ui=Image.open("powai.png")
  my_ui=my_ui.resize((700, 600))
  my_ui= ImageTk.PhotoImage(my_ui)
  label =Label(root, image=my_ui)
  label.grid(row=0,column=0,columnspan=4)
  labe12=Label(root,text=str(float(hu)/4700)+" square feet of property you are able to buy in Bopal")
  labe12.grid(row=3,column=0,columnspan=4)
 if(numbers==4):
  labe12.grid_forget()
  label.grid_forget()
  city_choice=Button(root,text="SG Highway",command=sg_highway)
  my_ui=Image.open("powai.png")
  my_ui=my_ui.resize((700, 600))
  my_ui= ImageTk.PhotoImage(my_ui)
  label =Label(root, image=my_ui)
  label.grid(row=0,column=0,columnspan=4)
  labe12=Label(root,text=str(float(hu)/7000)+" square feet of property you are able to buy in SG highway")
  labe12.grid(row=3,column=0,columnspan=4)
 if(numbers==5):
  labe12.grid_forget()
  label.grid_forget()
  city_choice=Button(root,text="Satellite",command=satellite)
  my_ui=Image.open("powai.png")
  my_ui=my_ui.resize((700, 600))
  my_ui= ImageTk.PhotoImage(my_ui)
  label =Label(root, image=my_ui)
  label.grid(row=0,column=0,columnspan=4)
  labe12=Label(root,text=str(float(hu)/6700)+" square feet of property you are able to buy in Satellite")
  labe12.grid(row=3,column=0,columnspan=4)
 if(numbers==6):
  labe12.grid_forget()
  label.grid_forget()
  city_choice=Button(root,text="Naroda",command=naroda)
  my_ui=Image.open("powai.png")
  my_ui=my_ui.resize((700, 600))
  my_ui= ImageTk.PhotoImage(my_ui)
  label =Label(root, image=my_ui)
  label.grid(row=0,column=0,columnspan=4)
  labe12=Label(root,text=str(float(hu)/3400)+" square feet of property you are able to buy in Naroda")
  labe12.grid(row=3,column=0,columnspan=4)
 if(numbers==1):
  
  label.grid_forget()
  city_choice=Button(root,text="Vaishnodevi Circle",command=Vaishnodevi_Circle)
  my_ui=Image.open("powai.png")
  my_ui=my_ui.resize((700, 600))
  my_ui= ImageTk.PhotoImage(my_ui)
  label =Label(root, image=my_ui)
  label.grid(row=0,column=0,columnspan=4)
  labe12=Label(root,text=str(float(hu)/5150)+" square feet of property you are able to buy in Vaishnodevi Circle")
  labe12.grid(row=3,column=0,columnspan=4)
 forward_button=Button(root,text=">",command=lambda:ahmedabad_areas(numbers+1))
 backward_button=Button(root,text="<",command=lambda:ahmedabad_areas(numbers-1))
 forward_button.grid(row=1,column=3)
 backward_button.grid(row=1,column=0)
 exit_button.grid(row=1,column=1)
 city_choice.grid(row=1,column=2)
def naroda():
 global label
 global forward_button
 global backward_button
 global city_choice
 city_choice.grid_forget()
 label.destroy()
 label1.destroy()
 root.destroy()
 top=Tk()
 data_points = np.array([20400, 20000, 23200, 24200, 25300, 24650, 25100, 27200, 27500, 26500,
                   26300, 28750, 29200, 28400, 27800, 27950, 28750, 29450, 29500, 27950,
                   28650, 28850, 28650, 29300, 28550, 28700, 29050, 28700, 28700, 29200,
                   28900, 30900, 30500, 30500, 30900, 31350, 31150, 31000, 34650, 33600,
                   35200])
 x_values = np.arange(len(data_points))
 coefficients = np.polyfit(x_values, data_points, 4)
 poly_equation = np.poly1d(coefficients)
 x_regression = np.linspace(0, len(data_points)+5, 100)
 y_regression = poly_equation(x_regression)
 plt.scatter(x_values, data_points, label='Data Points')
 plt.plot(x_regression, y_regression, label=f'4-Degree Polynomial Regression\n{poly_equation}', color='red')
 next_x_values = np.arange(len(data_points), len(data_points)+6)
 next_y_values = poly_equation(next_x_values)
 global label22
 label=Label(top,text="predicted values of property prices")
 label22=Label(top,text=next_y_values)
 label.grid(row=0,column=0,columnspan=2)
 label22.grid(row=0,column=2,columnspan=2)
 plt.scatter(next_x_values, next_y_values, label='Predicted Points', color='green', marker='x')
 plt.legend()
 plt.show()
def satellite():
 global label
 global forward_button
 global backward_button
 global city_choice
 city_choice.grid_forget()
 label.destroy()
 label1.destroy()
 root.destroy()
 top=Tk()
 data_points = np.array([20400, 20000, 23200, 24200, 25300, 24650, 25100, 27200, 27500, 26500,
                   26300, 28750, 29200, 28400, 27800, 27950, 28750, 29450, 29500, 27950,
                   28650, 28850, 28650, 29300, 28550, 28700, 29050, 28700, 28700, 29200,
                   28900, 30900, 30500, 30500, 30900, 31350, 31150, 31000, 34650, 33600,
                   35200])
 x_values = np.arange(len(data_points))
 coefficients = np.polyfit(x_values, data_points, 4)
 poly_equation = np.poly1d(coefficients)
 x_regression = np.linspace(0, len(data_points)+5, 100)
 y_regression = poly_equation(x_regression)
 plt.scatter(x_values, data_points, label='Data Points')
 plt.plot(x_regression, y_regression, label=f'4-Degree Polynomial Regression\n{poly_equation}', color='red')
 next_x_values = np.arange(len(data_points), len(data_points)+6)
 next_y_values = poly_equation(next_x_values)
 global label22
 label=Label(top,text="predicted values of property prices")
 label22=Label(top,text=next_y_values)
 label.grid(row=0,column=0,columnspan=2)
 label22.grid(row=0,column=2,columnspan=2)
 plt.scatter(next_x_values, next_y_values, label='Predicted Points', color='green', marker='x')
 plt.legend()
 plt.show()
def sg_highway():
 global label
 global forward_button
 global backward_button
 global city_choice
 city_choice.grid_forget()
 label.destroy()
 label1.destroy()
 root.destroy()
 top=Tk()
 data_points = np.array([20400, 20000, 23200, 24200, 25300, 24650, 25100, 27200, 27500, 26500,
                   26300, 28750, 29200, 28400, 27800, 27950, 28750, 29450, 29500, 27950,
                   28650, 28850, 28650, 29300, 28550, 28700, 29050, 28700, 28700, 29200,
                   28900, 30900, 30500, 30500, 30900, 31350, 31150, 31000, 34650, 33600,
                   35200])
 x_values = np.arange(len(data_points))
 coefficients = np.polyfit(x_values, data_points, 4)
 poly_equation = np.poly1d(coefficients)
 x_regression = np.linspace(0, len(data_points)+5, 100)
 y_regression = poly_equation(x_regression)
 plt.scatter(x_values, data_points, label='Data Points')
 plt.plot(x_regression, y_regression, label=f'4-Degree Polynomial Regression\n{poly_equation}', color='red')
 next_x_values = np.arange(len(data_points), len(data_points)+6)
 next_y_values = poly_equation(next_x_values)
 global label22
 label=Label(top,text="predicted values of property prices")
 label22=Label(top,text=next_y_values)
 label.grid(row=0,column=0,columnspan=2)
 label22.grid(row=0,column=2,columnspan=2)
 plt.scatter(next_x_values, next_y_values, label='Predicted Points', color='green', marker='x')
 plt.legend()
 plt.show()
def bopal():
 global label
 global forward_button
 global backward_button
 global city_choice
 city_choice.grid_forget()
 label.destroy()
 label1.destroy()
 root.destroy()
 top=Tk()
 data_points = np.array([20400, 20000, 23200, 24200, 25300, 24650, 25100, 27200, 27500, 26500,
                   26300, 28750, 29200, 28400, 27800, 27950, 28750, 29450, 29500, 27950,
                   28650, 28850, 28650, 29300, 28550, 28700, 29050, 28700, 28700, 29200,
                   28900, 30900, 30500, 30500, 30900, 31350, 31150, 31000, 34650, 33600,
                   35200])
 x_values = np.arange(len(data_points))
 coefficients = np.polyfit(x_values, data_points, 4)
 poly_equation = np.poly1d(coefficients)
 x_regression = np.linspace(0, len(data_points)+5, 100)
 y_regression = poly_equation(x_regression)
 plt.scatter(x_values, data_points, label='Data Points')
 plt.plot(x_regression, y_regression, label=f'4-Degree Polynomial Regression\n{poly_equation}', color='red')
 next_x_values = np.arange(len(data_points), len(data_points)+6)
 next_y_values = poly_equation(next_x_values)
 global label22
 label=Label(top,text="predicted values of property prices")
 label22=Label(top,text=next_y_values)
 label.grid(row=0,column=0,columnspan=2)
 label22.grid(row=0,column=2,columnspan=2)
 plt.scatter(next_x_values, next_y_values, label='Predicted Points', color='green', marker='x')
 plt.legend()
 plt.show()
def chandkheda():
 global label
 global forward_button
 global backward_button
 global city_choice
 city_choice.grid_forget()
 label.destroy()
 label1.destroy()
 root.destroy()
 top=Tk()
 data_points = np.array([20400, 20000, 23200, 24200, 25300, 24650, 25100, 27200, 27500, 26500,
                   26300, 28750, 29200, 28400, 27800, 27950, 28750, 29450, 29500, 27950,
                   28650, 28850, 28650, 29300, 28550, 28700, 29050, 28700, 28700, 29200,
                   28900, 30900, 30500, 30500, 30900, 31350, 31150, 31000, 34650, 33600,
                   35200])
 x_values = np.arange(len(data_points))
 coefficients = np.polyfit(x_values, data_points, 4)
 poly_equation = np.poly1d(coefficients)
 x_regression = np.linspace(0, len(data_points)+5, 100)
 y_regression = poly_equation(x_regression)
 plt.scatter(x_values, data_points, label='Data Points')
 plt.plot(x_regression, y_regression, label=f'4-Degree Polynomial Regression\n{poly_equation}', color='red')
 next_x_values = np.arange(len(data_points), len(data_points)+6)
 next_y_values = poly_equation(next_x_values)
 global label22
 label=Label(top,text="predicted values of property prices")
 label22=Label(top,text=next_y_values)
 label.grid(row=0,column=0,columnspan=2)
 label22.grid(row=0,column=2,columnspan=2)
 plt.scatter(next_x_values, next_y_values, label='Predicted Points', color='green', marker='x')
 plt.legend()
 plt.show()
def Vaishnodevi_Circle():
 global label
 global forward_button
 global backward_button
 global city_choice
 city_choice.grid_forget()
 label.destroy()
 label1.destroy()
 root.destroy()
 top=Tk()
 data_points = np.array([20400, 20000, 23200, 24200, 25300, 24650, 25100, 27200, 27500, 26500,
                   26300, 28750, 29200, 28400, 27800, 27950, 28750, 29450, 29500, 27950,
                   28650, 28850, 28650, 29300, 28550, 28700, 29050, 28700, 28700, 29200,
                   28900, 30900, 30500, 30500, 30900, 31350, 31150, 31000, 34650, 33600,
                   35200])
 x_values = np.arange(len(data_points))
 coefficients = np.polyfit(x_values, data_points, 4)
 poly_equation = np.poly1d(coefficients)
 x_regression = np.linspace(0, len(data_points)+5, 100)
 y_regression = poly_equation(x_regression)
 plt.scatter(x_values, data_points, label='Data Points')
 plt.plot(x_regression, y_regression, label=f'4-Degree Polynomial Regression\n{poly_equation}', color='red')
 next_x_values = np.arange(len(data_points), len(data_points)+6)
 next_y_values = poly_equation(next_x_values)
 global label22
 label=Label(top,text="predicted values of property prices")
 label22=Label(top,text=next_y_values)
 label.grid(row=0,column=0,columnspan=2)
 label22.grid(row=0,column=2,columnspan=2)
 plt.scatter(next_x_values, next_y_values, label='Predicted Points', color='green', marker='x')
 plt.legend()
 plt.show()
def banglore_areas(numbers):
 global labe12
 global hu
 hu=e.get()
 e.grid_forget()
 labe12.grid_forget()
 global label1
 label1.grid_forget()
 label1=Label(root,text="please select your desired area of your choice in banglore")
 label1.grid(row=2,column=0,columnspan=2)
 global label
 global forward_button
 global backward_button
 global city_choice
 mylist.clear()
 label.grid_forget()
 city_choice.grid_forget()
 if(numbers==0):
    numbers=6
 if(numbers==7):
    numbers=1
 if(numbers==2):
  labe12.grid_forget()
  label.grid_forget()
  city_choice=Button(root,text="Yeshwantpur",command=yeshwantpur)
  my_ui=Image.open("powai.png")
  my_ui=my_ui.resize((700, 600))
  my_ui= ImageTk.PhotoImage(my_ui)
  label =Label(root, image=my_ui)
  label.grid(row=0,column=0,columnspan=4)
  labe12=Label(root,text=str(float(hu)/8500)+" square feet of property you are able to buy in yeshwantpur")
  labe12.grid(row=3,column=0,columnspan=4)
 if(numbers==3):
  labe12.grid_forget()
  label.grid_forget()
  city_choice=Button(root,text="Mysore Road",command=mysore_road)
  my_ui=Image.open("powai.png")
  my_ui=my_ui.resize((700, 600))
  my_ui= ImageTk.PhotoImage(my_ui)
  label =Label(root, image=my_ui)
  label.grid(row=0,column=0,columnspan=4)
  labe12=Label(root,text=str(float(hu)/6500)+" square feet of property you are able to buy in mysore road")
  labe12.grid(row=3,column=0,columnspan=4)
 if(numbers==4):
  labe12.grid_forget()
  label.grid_forget()
  city_choice=Button(root,text="Whitefield",command=whitefield)
  my_ui=Image.open("powai.png")
  my_ui=my_ui.resize((700, 600))
  my_ui= ImageTk.PhotoImage(my_ui)
  label =Label(root, image=my_ui)
  label.grid(row=0,column=0,columnspan=4)
  labe12=Label(root,text=str(float(hu)/9200)+" square feet of property you are able to buy in whitefield")
  labe12.grid(row=3,column=0,columnspan=4)
 if(numbers==5):
  labe12.grid_forget()
  label.grid_forget()
  city_choice=Button(root,text="Hebbal",command=hebbal)
  my_ui=Image.open("powai.png")
  my_ui=my_ui.resize((700, 600))
  my_ui= ImageTk.PhotoImage(my_ui)
  label =Label(root, image=my_ui)
  label.grid(row=0,column=0,columnspan=4)
  labe12=Label(root,text=str(float(hu)/10800)+" square feet of property you are able to buy in hebbal")
  labe12.grid(row=3,column=0,columnspan=4)
 if(numbers==6):
  labe12.grid_forget()
  label.grid_forget()
  city_choice=Button(root,text="Sarjapur",command=sarajpur)
  my_ui=Image.open("powai.png")
  my_ui=my_ui.resize((700, 600))
  my_ui= ImageTk.PhotoImage(my_ui)
  label =Label(root, image=my_ui)
  label.grid(row=0,column=0,columnspan=4)
  labe12=Label(root,text=str(float(hu)/5700)+" square feet of property you are able to buy in sarajpur")
  labe12.grid(row=3,column=0,columnspan=4)
 if(numbers==1):
  city_choice=Button(root,text="Thanisandra",command=Thanisandra)
  my_ui=Image.open("powai.png")
  my_ui=my_ui.resize((700, 600))
  my_ui= ImageTk.PhotoImage(my_ui)
  label =Label(root, image=my_ui)
  label.grid(row=0,column=0,columnspan=4)
  labe12=Label(root,text=str(float(hu)/8500)+" square feet of property you are able to buy in Thanisandra")
  labe12.grid(row=3,column=0,columnspan=4)
 forward_button=Button(root,text=">",command=lambda:banglore_areas(numbers+1))
 backward_button=Button(root,text="<",command=lambda:banglore_areas(numbers-1))
 forward_button.grid(row=1,column=3)
 backward_button.grid(row=1,column=0)
 exit_button.grid(row=1,column=1)
 city_choice.grid(row=1,column=2)
def mysore_road():
 global label
 global forward_button
 global backward_button
 global city_choice
 city_choice.grid_forget()
 label.destroy()
 label1.destroy()
 root.destroy()
 top=Tk()
 data_points = np.array([20400, 20000, 23200, 24200, 25300, 24650, 25100, 27200, 27500, 26500,
                   26300, 28750, 29200, 28400, 27800, 27950, 28750, 29450, 29500, 27950,
                   28650, 28850, 28650, 29300, 28550, 28700, 29050, 28700, 28700, 29200,
                   28900, 30900, 30500, 30500, 30900, 31350, 31150, 31000, 34650, 33600,
                   35200])
 x_values = np.arange(len(data_points))
 coefficients = np.polyfit(x_values, data_points, 4)
 poly_equation = np.poly1d(coefficients)
 x_regression = np.linspace(0, len(data_points)+5, 100)
 y_regression = poly_equation(x_regression)
 plt.scatter(x_values, data_points, label='Data Points')
 plt.plot(x_regression, y_regression, label=f'4-Degree Polynomial Regression\n{poly_equation}', color='red')
 next_x_values = np.arange(len(data_points), len(data_points)+6)
 next_y_values = poly_equation(next_x_values)
 global label22
 label=Label(top,text="predicted values of property prices")
 label22=Label(top,text=next_y_values)
 label.grid(row=0,column=0,columnspan=2)
 label22.grid(row=0,column=2,columnspan=2)
 plt.scatter(next_x_values, next_y_values, label='Predicted Points', color='green', marker='x')
 plt.legend()
 plt.show()
def yeshwantpur():
 global label
 global forward_button
 global backward_button
 global city_choice
 city_choice.grid_forget()
 label.destroy()
 label1.destroy()
 root.destroy()
 top=Tk()
 data_points = np.array([20400, 20000, 23200, 24200, 25300, 24650, 25100, 27200, 27500, 26500,
                   26300, 28750, 29200, 28400, 27800, 27950, 28750, 29450, 29500, 27950,
                   28650, 28850, 28650, 29300, 28550, 28700, 29050, 28700, 28700, 29200,
                   28900, 30900, 30500, 30500, 30900, 31350, 31150, 31000, 34650, 33600,
                   35200])
 x_values = np.arange(len(data_points))
 coefficients = np.polyfit(x_values, data_points, 4)
 poly_equation = np.poly1d(coefficients)
 x_regression = np.linspace(0, len(data_points)+5, 100)
 y_regression = poly_equation(x_regression)
 plt.scatter(x_values, data_points, label='Data Points')
 plt.plot(x_regression, y_regression, label=f'4-Degree Polynomial Regression\n{poly_equation}', color='red')
 next_x_values = np.arange(len(data_points), len(data_points)+6)
 next_y_values = poly_equation(next_x_values)
 global label22
 label=Label(top,text="predicted values of property prices")
 label22=Label(top,text=next_y_values)
 label.grid(row=0,column=0,columnspan=2)
 label22.grid(row=0,column=2,columnspan=2)
 plt.scatter(next_x_values, next_y_values, label='Predicted Points', color='green', marker='x')
 plt.legend()
 plt.show()
def Thanisandra():
 global label
 global forward_button
 global backward_button
 global city_choice
 city_choice.grid_forget()
 label.destroy()
 label1.destroy()
 root.destroy()
 top=Tk()
 data_points = np.array([20400, 20000, 23200, 24200, 25300, 24650, 25100, 27200, 27500, 26500,
                   26300, 28750, 29200, 28400, 27800, 27950, 28750, 29450, 29500, 27950,
                   28650, 28850, 28650, 29300, 28550, 28700, 29050, 28700, 28700, 29200,
                   28900, 30900, 30500, 30500, 30900, 31350, 31150, 31000, 34650, 33600,
                   35200])
 x_values = np.arange(len(data_points))
 coefficients = np.polyfit(x_values, data_points, 4)
 poly_equation = np.poly1d(coefficients)
 x_regression = np.linspace(0, len(data_points)+5, 100)
 y_regression = poly_equation(x_regression)
 plt.scatter(x_values, data_points, label='Data Points')
 plt.plot(x_regression, y_regression, label=f'4-Degree Polynomial Regression\n{poly_equation}', color='red')
 next_x_values = np.arange(len(data_points), len(data_points)+6)
 next_y_values = poly_equation(next_x_values)
 global label22
 label=Label(top,text="predicted values of property prices")
 label22=Label(top,text=next_y_values)
 label.grid(row=0,column=0,columnspan=2)
 label22.grid(row=0,column=2,columnspan=2)
 plt.scatter(next_x_values, next_y_values, label='Predicted Points', color='green', marker='x')
 plt.legend()
 plt.show()
def whitefield():
 global label
 global forward_button
 global backward_button
 global city_choice
 city_choice.grid_forget()
 label.destroy()
 label1.destroy()
 root.destroy()
 top=Tk()
 data_points = np.array([20400, 20000, 23200, 24200, 25300, 24650, 25100, 27200, 27500, 26500,
                   26300, 28750, 29200, 28400, 27800, 27950, 28750, 29450, 29500, 27950,
                   28650, 28850, 28650, 29300, 28550, 28700, 29050, 28700, 28700, 29200,
                   28900, 30900, 30500, 30500, 30900, 31350, 31150, 31000, 34650, 33600,
                   35200])
 x_values = np.arange(len(data_points))
 coefficients = np.polyfit(x_values, data_points, 4)
 poly_equation = np.poly1d(coefficients)
 x_regression = np.linspace(0, len(data_points)+5, 100)
 y_regression = poly_equation(x_regression)
 plt.scatter(x_values, data_points, label='Data Points')
 plt.plot(x_regression, y_regression, label=f'4-Degree Polynomial Regression\n{poly_equation}', color='red')
 next_x_values = np.arange(len(data_points), len(data_points)+6)
 next_y_values = poly_equation(next_x_values)
 global label22
 label=Label(top,text="predicted values of property prices")
 label22=Label(top,text=next_y_values)
 label.grid(row=0,column=0,columnspan=2)
 label22.grid(row=0,column=2,columnspan=2)
 plt.scatter(next_x_values, next_y_values, label='Predicted Points', color='green', marker='x')
 plt.legend()
 plt.show()
def sarajpur():
 global label
 global forward_button
 global backward_button
 global city_choice
 city_choice.grid_forget()
 label.destroy()
 label1.destroy()
 root.destroy()
 top=Tk()
 data_points = np.array([20400, 20000, 23200, 24200, 25300, 24650, 25100, 27200, 27500, 26500,
                   26300, 28750, 29200, 28400, 27800, 27950, 28750, 29450, 29500, 27950,
                   28650, 28850, 28650, 29300, 28550, 28700, 29050, 28700, 28700, 29200,
                   28900, 30900, 30500, 30500, 30900, 31350, 31150, 31000, 34650, 33600,
                   35200])
 x_values = np.arange(len(data_points))
 coefficients = np.polyfit(x_values, data_points, 4)
 poly_equation = np.poly1d(coefficients)
 x_regression = np.linspace(0, len(data_points)+5, 100)
 y_regression = poly_equation(x_regression)
 plt.scatter(x_values, data_points, label='Data Points')
 plt.plot(x_regression, y_regression, label=f'4-Degree Polynomial Regression\n{poly_equation}', color='red')
 next_x_values = np.arange(len(data_points), len(data_points)+6)
 next_y_values = poly_equation(next_x_values)
 global label22
 label=Label(top,text="predicted values of property prices")
 label22=Label(top,text=next_y_values)
 label.grid(row=0,column=0,columnspan=2)
 label22.grid(row=0,column=2,columnspan=2)
 plt.scatter(next_x_values, next_y_values, label='Predicted Points', color='green', marker='x')
 plt.legend()
 plt.show()
def hebbal():
 global label
 global forward_button
 global backward_button
 global city_choice
 city_choice.grid_forget()
 label.destroy()
 label1.destroy()
 root.destroy()
 top=Tk()
 data_points = np.array([20400, 20000, 23200, 24200, 25300, 24650, 25100, 27200, 27500, 26500,
                   26300, 28750, 29200, 28400, 27800, 27950, 28750, 29450, 29500, 27950,
                   28650, 28850, 28650, 29300, 28550, 28700, 29050, 28700, 28700, 29200,
                   28900, 30900, 30500, 30500, 30900, 31350, 31150, 31000, 34650, 33600,
                   35200])
 x_values = np.arange(len(data_points))
 coefficients = np.polyfit(x_values, data_points, 4)
 poly_equation = np.poly1d(coefficients)
 x_regression = np.linspace(0, len(data_points)+5, 100)
 y_regression = poly_equation(x_regression)
 plt.scatter(x_values, data_points, label='Data Points')
 plt.plot(x_regression, y_regression, label=f'4-Degree Polynomial Regression\n{poly_equation}', color='red')
 next_x_values = np.arange(len(data_points), len(data_points)+6)
 next_y_values = poly_equation(next_x_values)
 global label22
 label=Label(top,text="predicted values of property prices")
 label22=Label(top,text=next_y_values)
 label.grid(row=0,column=0,columnspan=2)
 label22.grid(row=0,column=2,columnspan=2)
 plt.scatter(next_x_values, next_y_values, label='Predicted Points', color='green', marker='x')
 plt.legend()
 plt.show()
labe12=Label(root,text="enter your budget")
labe12.grid(row=3,column=0,columnspan=2)
e=Entry(root,width=50)
e.grid(row=3,column=2,columnspan=2)
img2 = Image.open("banglore.jpg")
img1=Image.open("delhi.jpg")
img=Image.open("mumbai.jpg")
img3=Image.open("kolkata..jpg")
img4=Image.open("ahmedabad.jpg")
img = img.resize((700, 600))
img = ImageTk.PhotoImage(img)
label =Label(root, image=img)
label.grid(row=0,column=0,columnspan=4)
img1= img1.resize((700, 600))
img2= img2.resize((700, 600))
img3= img3.resize((700, 600))
img4= img4.resize((700, 600))
img1= ImageTk.PhotoImage(img1)
img2= ImageTk.PhotoImage(img2)
img3= ImageTk.PhotoImage(img3)
img4= ImageTk.PhotoImage(img4)
mylist=[img,img1,img2,img3,img4]
forward_button=Button(root,text=">",command=lambda:forward(2))
backward_button=Button(root,text="<",command=lambda:backward(5))
exit_button=Button(root,text="exit program",command=root.quit)
city_choice=Button(root,text="mumbai",command=lambda:mumbai_areas(1))
forward_button.grid(row=1,column=3)
backward_button.grid(row=1,column=0)
exit_button.grid(row=1,column=1)
city_choice.grid(row=1,column=2)
label1=Label(root,text="Select the city where you want to but the property or where you want to invest")
label1.grid(row=2,column=0,columnspan=4)
root.mainloop()
